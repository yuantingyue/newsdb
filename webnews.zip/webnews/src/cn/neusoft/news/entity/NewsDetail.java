package cn.neusoft.news.entity;


public class NewsDetail extends News {
	private String tname;

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}
	
}
